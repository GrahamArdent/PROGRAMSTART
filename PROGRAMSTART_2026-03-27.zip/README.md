# PROGRAMSTART

Purpose: Organized planning workspace for reusable product-start kits.
Last updated: 2026-03-27

---

## Structure

### `PROGRAMBUILD/`

Contains the exported PROGRAMBUILD planning system, including kickoff, architecture, requirements, risk, testing, and release-readiness documents.

### `USERJOURNEY/`

Contains the full USERJOURNEY planning package for signup, onboarding, consent, activation, analytics, and first-run routing.

### `BACKUPS/2026-03-27_pre-structure_flat_export_snapshot/`

Contains a pre-reorganization snapshot of the original flat markdown exports from the PROGRAMSTART root.

## Why This Layout Exists

This workspace keeps the two planning systems separated but adjacent:

1. `PROGRAMBUILD/` is the reusable product and execution starter kit
2. `USERJOURNEY/` is the reusable onboarding and consent subsystem

The backup snapshot exists so the original flat export state is preserved before restructuring.

## Recommended Use

1. start with `PROGRAMBUILD/` when defining product scope, architecture, and execution framing
2. use `USERJOURNEY/` when the product needs account creation, onboarding, consent, or activation planning
3. use the USERJOURNEY delivery gameplan to keep route, legal, analytics, and implementation-planning docs synchronized

## Safety Notes

1. the original flat exports were copied into `BACKUPS/2026-03-27_pre-structure_flat_export_snapshot/` before any moves were made
2. the full USERJOURNEY package was copied from the Resume Creator V6 source workspace into `USERJOURNEY/`
3. this workspace is organized non-destructively around preserved copies, not a single fragile export