# Backbone ecosystem audit: research, preliminary findings and execution blueprint

**Reference ID:** BACKBONE-AUDIT-2026-10-27  
**Prepared for:** Graham Hill  
**Date:** October 27, 2026 · America/Toronto  
**Status:** Research and bounded documentary audit complete; comprehensive runtime audit and remediation NOT performed.  
**Scope:** Core autonomous backbone, its assurance machinery and necessary shared dependencies. Product applications are excluded except for their interfaces with shared backbone services.  
**Authority:** Advisory reference. Existing repository owners, accepted decisions and current execution plans remain authoritative.

## 1. Recommendation

Run one outcome-based backbone audit, organized around the complete path from an authorized objective to a verified result and its durable recovery. Reconcile three inventories:

1. **Intended system:** current owner contracts, responsibilities, accepted capabilities and required outcomes.
2. **Actual system:** installed artifacts, processes, schedules, configurations, identities, data stores, event subscriptions and observed transactions.
3. **Unadopted work:** accepted ideas, prepared patches, open PRs, experiment findings and tested repairs that have not reached their intended consumers.

The differences between these inventories are the audit's most useful output. Repository-by-repository test counts alone cannot establish whether the backbone works.

The target should be **the lowest ongoing complexity and operating cost that meets explicit correctness, reliability, security and recovery requirements**. The fewest tests, repositories or services is not necessarily the best system. Preserve useful isolation, independent verification and recovery paths. Remove machinery that has no justified outcome, unique protection or accepted dependency.

Start with existing owner records and produce a small linked audit register. Reuse Paths, Evidence Spine, Matrix, Controller, Watchtower and Mission-Control according to their actual accepted capabilities. Do not build another controller, catalog service, scheduler, evidence database or master plan just to conduct the audit.

### What this report does and does not establish

This research reviewed primary external sources, five current saved backbone records, current selected GitHub owner issues/comments, two PRs and twelve repository READMEs. It reconciles material recent findings and proposes a practical audit method. No repository tests, host inventories, live failure injections, credential operations, workflow changes, source publications or deployments were performed in this turn.

The latest CI210 reference retrieved was modified at **14:33:42 Toronto time on October 27**, and includes revision 18 plus later execution amendments, including Q06 custody source reconstruction. The morning CI failure audit is historical evidence within this newer state. Current selected GitHub reads were performed during this research. These observations are not an atomic snapshot of the entire ecosystem.

No exact ecosystem-wide total of tests, E2Es, stale jobs or removable components is established. Producing those totals truthfully is a deliverable of the proposed audit.

## 2. What the external research supports

The following are research conclusions, followed by their proposed application here. The ecosystem-specific design is an inference from these sources and the inspected owner records, not a prescribed industry standard.

| Research basis | Relevant finding | Application to this backbone |
|---|---|---|
| NIST CSF 2.0, asset management [R01] | Inventory software, services, systems, data and authorized flows; manage their lifecycle and prioritize by mission impact. | Include runtime jobs, identities, stores and provider subscriptions, not just GitHub repositories. Explicitly record discovery coverage and unknowns. |
| Google SRE, testing [R02] | Offline tests and production observations answer different questions; configuration/version differences matter. | Separate unit, contract, native-platform, installed and natural-use evidence. Bind results to the actual source and environment. |
| Google SRE, simplicity [R03] | Accidental complexity, dead code and unnecessarily broad interfaces increase maintenance burden. | Require a purpose and owner for every active component; remove obsolete paths after dependency and recovery analysis. |
| DORA, test automation [R04] | Maintain fast, reliable tests, review their usefulness and improve early defect detection. Its guidance favors short feedback cycles and selective acceptance coverage in existing systems. | Start with important backbone journeys and meaningful existing tests. Measure feedback time and escaped defects; do not retrofit thousands of low-value tests first. |
| Google research, mutation testing [R05] | Deliberate small code faults assess whether tests detect wrong behavior; broad mutation analysis can be costly. | Apply targeted negative controls to critical guards and recently changed boundaries. Avoid an expensive ecosystem-wide mutation campaign on every commit. |
| Google testing, flakiness [R06] | Flaky signals consume effort and can hide real defects; retries and quarantine have limitations. | Track original failures, reruns and flakes separately. Any quarantine needs an owner, expiry and alternative protection. |
| Pact documentation [R07] | Executable consumer/provider contract examples test how integrations are actually used. | Verify real producers and consumers against shared examples. Schema equality alone is insufficient. Adopting Pact infrastructure is optional. |
| SLSA 1.2 provenance [R08] | Provenance links artifacts to their build process, inputs and builder identity. | Bind test/release evidence to immutable subjects and trusted verification. Provenance does not by itself prove behavior or honesty of candidate-generated test summaries. |
| OpenTelemetry context propagation [R09] | Correlation context connects observations across process boundaries; incoming context may be untrusted. | Reuse original request/attempt/effect IDs to trace work end to end. Trace IDs are correlation, not authorization or proof that evidence influenced a decision. |
| AWS Builders' Library, idempotent APIs [R10] | Explicit request identity and atomic handling help make retries safe and auditable. | Test lost acknowledgement, duplicate delivery and restart recovery using the original identity. A timeout is not proof that no effect occurred. |
| GitHub Actions concurrency and skipping [R11–R12] | Concurrency controls simultaneous work; skipped workflows can leave required checks pending. | Measure starts, jobs, cancellations and execution separately. Cancellation and skip markers do not establish pre-publication enforcement. |
| Backstage catalog model [R13] | Source-owned metadata can expose components and ownership in a derived catalog. | Borrow the ownership/relationship model in existing records. A new Backstage deployment is not justified by this audit. |
| Google SRE, SLOs and monitoring [R14–R15] | Reliability targets guide priorities; externally visible behavior and actionable signals matter. | Judge the backbone by correct useful outcomes, bounded recovery and trustworthy status. Audit the alert path through actual acknowledgement. |
| Principles of Chaos Engineering [R16] | Controlled experiments start with measurable behavior and try to falsify resilience assumptions. | Begin with isolated replay and fault fixtures. Live disruptions require a separately admitted scope, finite limits and rollback. |

These sources support reducing waste, but they do not justify deleting old tests merely because they are old, collapsing trust boundaries for convenience, or declaring a system correct from a green build.

## 3. Define the backbone boundary before counting anything

A component is in scope if it selects, authorizes, routes, executes, observes, records, recovers or presents backbone work, or is a required dependency of one of those functions.

| Area | Initial repositories/surfaces | What to audit |
|---|---|---|
| Methodology and semantic contracts | PROGRAMSTART | Accepted outcomes, compilation/narrowing, challenge and closure rules, propagation to consumers. |
| Durable orchestration | programstart-autonomous-controller | Admission, work state, continuation, original attempts, claims, recovery, outcome acceptance. |
| Execution fabric | programstart-compute-spine | Routing, fixed work profiles, isolation, resource limits, source transfer, publication and receipts. |
| Worker and host control | execution-node-control; Ubuntu Execution Node, VPS, relevant Windows transport | Installed release/configuration, request/result behavior, services, schedules and recovery. |
| Connectivity discovery | paths | Actor/effect/target lookup, equivalent routes, currentness, invocation and discovery adoption. |
| Identity and custody | secrets-control-plane; relevant provider identities | Least privilege, protected custody, issuance, expiry/revocation and recovery, using metadata rather than secret values. |
| Sensing and incident evidence | repo-watchtower | Actual repository coverage, event intake, persistence, sensing, delivery and failure visibility. |
| Evidence and acceptance linkage | evidence-spine | Provenance, invalidation, scoped acceptance and reproducible derived state. |
| Current-state projection | ecosystem-matrix | Owner reconstruction, expiry, stale-state handling and consumer use; currently bounded coverage. |
| Operator surface | mission-control | What it displays, source freshness, drill-down, permitted interaction and actual delivery paths. |
| Assurance and decision lifecycle | ecosystem-lab; decision-lifecycle; any discovered Challenge/Portfolio/Decision Closure dependencies | Experiment-to-owner adoption, outstanding decisions and audit-related duplication. Verify actual responsibility and runtime before assuming deployment. |

The first ten repository roles are supported by current READMEs and/or owner evidence. Ecosystem Lab's README explicitly describes non-authoritative experimental infrastructure. Decision Lifecycle's README is largely scaffold-level and is insufficient to establish a deployed decision service. Portfolio Operations, Ecosystem Challenge and Decision Closure appear as dependency references; their exact present implementations must be resolved during scope discovery.

Resume Creator, GCRM, Dedication, LinkedIn Generator and other products are outside this audit's feature scope. A product's use of a shared backbone API, shared resource pool or shared credential boundary remains in scope only to the extent needed to assess that dependency.

Avoid an arbitrary repository-count target. A small shared library or scheduled job outside the initial list can be more important than an entire product repository.

## 4. Preliminary findings grounded in current records

These are documentary findings. “Recorded” means the owner/source record was read; it does not mean the reported experiment was independently rerun here.

| ID | Finding and current interpretation | Evidence and next audit question |
|---|---|---|
| F01 | **The October 27 CI burst was real, but its morning failure state is superseded in part.** The audit recorded 27 runs across nine updates: 13 failures, 12 cancellations and two successes. Current PR579 records repaired focused behavior and 108 passing selected tests. | [I01], [I02], [I06]. Preserve the original incident; do not reopen the already repaired legacy-envelope failures. Full-repository acceptance remains separate. |
| F02 | **A trustworthy positive local-CI verdict is still an explicit gap.** Latest Q02–Q04 evidence reports a hostile import changing unittest reporting so a failed assertion appeared successful. The correction holds positive in-process telemetry as INCONCLUSIVE. | [I02], [I07]. Independently authenticated positive verification is not yet established by that correction. Test both rejection of false success and acceptance of a genuinely valid candidate. |
| F03 | **Source-prepared improvements are not consistently equivalent to installed capability.** PR579 remains draft/unmerged at 11b11950e92bfe262b46d861bb7a943ef45a299a. Paths PR81 remains draft/unmerged at 83e22aadbb07f07b39badda1a2b7a914c058dc21. | [I03], [I06], [I08]. Create an adoption chain for each selected fix: decision → source → tests → package → installed consumer → observed outcome. |
| F04 | **Preserving evidence pointers does not prove evidence use.** PROGRAMSTART256 records the H2 pointer repair and tests, while source retrieval, currentness, replacement semantics and material use remain incomplete. | [I04–I05], [I09]. Use independent output expectations and material-versus-irrelevant input pairs, not only matching references or telemetry. |
| F05 | **Whole-test accounting and native parity matter.** PR579 reports 1,936 discovered cases and 1,894 run, with failure/error/skip records. The newer handoff explains setup/class-skip accounting; the numerical difference is no longer unexplained. | [I02], [I06]. Qualify actual remaining dependencies and environment-bound cases. Neither subtracting environmental errors nor counting fixture passes earns full acceptance. |
| F06 | **Route discovery is a real integration concern.** PR81 contains a lookup safeguard, but its saved checkpoint does not establish executed full candidate suites or installed/enforced consumers. | [I03], [I08], [I10]. Audit callable exposure, actor admission, fixed action, target and effect separately. ER033's fixed Windows probe is not ER034's general operator access. |
| F07 | **Watchtower coverage and delivery cannot be inferred from provider registration.** Latest reference distinguishes five selected provider repository IDs from a last-observed installed three-ID allowlist; native PostgreSQL, real Controller acknowledgement and installed recovery remain open. | [I02], [I11]. Refresh actual runtime and follow one event through detector, persistence, receiver, acknowledgement and status. The three-ID figure is historical observation, not a fresh host inventory. |
| F08 | **Publication recovery has a continuity problem beyond comparing SHAs.** Q02–Q04 records an away-and-back ref change, or ABA, defeating the first recovery approach. Corrected source holds continuity-unverified replays. | [I02], [I07]. Verify original-effect recovery using trustworthy history/generation or explicitly accepted bounded semantics; never credit a hold as successful recovery. |
| F09 | **There is useful custody source work to reconcile.** Latest Q06 amendment records a reconstructed fixed CI custody binding and 27 local tests, with real key/token/provider/native acceptance still open. | [I02]. Integrate or deliberately defer through Secrets/CI210 ownership; do not mistake partial materialization for complete upstream qualification. |
| F10 | **Documentation entry points can disagree in maturity.** Controller README still describes a greenfield bootstrap while current cross-owner records discuss later source/runtime work. Secrets README carries an early reviewed date. | Current README blobs in Appendix B. Treat these as reconciliation candidates. Neither old wording nor a date proves running code is obsolete. |
| F11 | **There is no refreshed ecosystem-wide runtime inventory in this review.** No complete systemd/cron/Windows-task/container/provider subscription comparison was performed. | Explicit evidence limit. “Old legacy stuff is still running” is a valid hypothesis, not yet an established inventory finding. |
| F12 | **Existing tests can be valuable despite legacy names.** Current PR579 preserved 15 legacy stage-error cases; the incident showed compatibility assertions mattered. | [I01], [I06]. Retire tests based on the contract and unique fault detection, not age, naming or inconvenience. |

The newest handoff also records selected Q01 source tests and later Q02–Q04 hardening tests. These overlap other suites and refer to different candidate subjects. Do not add all quoted pass counts into one ecosystem test total.

## 5. Keep the audit organized with one small register and derived views

Use one audit ID and one findings register within the existing accepted owner structure. This reference does not select a new storage format or change an owner contract.

The register should generate four working views:

1. **Component and runtime view:** what exists, who owns it, where it runs, and what it supports.
2. **Outcome and test view:** which tests and observations justify each outcome and failure boundary.
3. **Adoption and finding view:** unfinished work, duplicate work, blockers, decisions and exact next actions.
4. **Cost and retirement view:** ongoing burden, proposed reductions, retained protection and rollback.

Start with existing fields and stable IDs. Add only missing fields whose use is demonstrated. Do not maintain four manually duplicated descriptions.

### Minimum audit record

| Record | Essential fields |
|---|---|
| Component/runtime | Stable identity; owner; purpose; source; installed artifact/config identity; host/provider; lifecycle; callers/callees; trigger; resources; last observation; invalidators. |
| Boundary/contract | Producer; consumer; entry point; accepted version/semantics; identity/currentness rules; failure/retry behavior; persistence and installer dependencies. |
| Test/evidence | Outcome/risk ID; actual test ID; command/entry point; source and test identities; environment/dependencies; substituted boundaries; independent expected result; outcome/log reference; skip/flake history. |
| Improvement | Existing decision/finding ID; source/PR/archive; tested subject; adoption state per consumer; dependency; next action; owner; deliberate deferral or rejection reason. |
| Finding/disposition | Observation; inference; unknowns; consequence; severity; existing owner issue; required proof; action; rollback; closure evidence. |

Use separate dimensions for **authority**, **implementation**, **verification** and **activation**. A single linear progress bar loses too much information: code may be installed without acceptance, a fix may be tested but unpublished, and historical proof may have been invalidated.

Every record needs an observation time and invalidation rule. Use exact refs/digests for evidence; moving branch links are navigation aids. For cross-repository snapshots, record each repository separately and reconcile changes during the audit rather than pretending the reads were atomic.

### Completeness without false promises

Create explicit denominators: repositories, hosts, runtime units, trigger routes, consumers, outcomes and tests in the declared scope. For each discovery surface record queried scope, pagination, observation time and success/denial/inaccessibility. An unavailable inventory is UNKNOWN, not empty.

Reconcile:

- registered components against runtime observations;
- runtime processes against source/deployment ownership;
- declared consumers against imports, call sites, message handlers, persisted readers and installers;
- workflow-selected tests against tests actually discovered and executed;
- selected findings against owner dispositions and acceptance evidence.

An unmapped item is visible debt. “100% mapped” is valid only for a named frozen inventory. It cannot mean every historical conversation or undiscovered component was covered.

## 6. Audit whether the tests justify the system

Classify existing tests before creating new ones.

| Layer | What it can establish | Common overclaim to reject |
|---|---|---|
| Static/structural | Syntax, schema shape, selected references and packaging declarations. | “The actual runtime behavior works.” |
| Unit/component | Defined behavior of a real implementation under controlled inputs. | “The neighboring services agree.” |
| Contract | Real producer and consumer compatibility for supported examples/versions. | “The full workflow completes.” |
| Integration | Real selected components interact correctly. | “All production boundaries were exercised.” |
| Native/platform | Required OS, process, socket, database or credential primitive behavior. | “A substitute database or mocked OS earned native proof.” |
| Installed smoke | The deployed artifact/config exposes the expected narrow behavior. | “A narrow health check proves a useful complete task.” |
| End-to-end journey | A declared entry point reaches the intended outcome across required boundaries. | “An inner helper or seeded receipt represents the whole chain.” |
| Natural operation/recovery | A useful admitted task and its recovery work in the real operating context. | “One successful sample proves indefinite unattended reliability.” |

For every important test, answer:

- Which current requirement or historical incident does it protect?
- Does it call the actual implementation and entry point?
- What observable wrong behavior must make it fail?
- Is the expected result independent of the code under test?
- Which boundaries are simulated, and why?
- Could a dependency skip, zero collection, setup failure, retry, cache or forged summary produce apparent success?
- Is it selected by the real workflow when the relevant source, test, schema, dependency or installer changes?
- What exact source/environment did its latest meaningful result cover?
- Does it overlap another test while protecting the same failure in the same environment, or protect a genuinely different boundary?

### Test the tests

Use a small risk-selected falsification set: remove a required context reference; widen a forbidden target; accept a stale packet; bypass a receipt check; lose an installer file; count duplicate events twice; suppress an assertion; drop an acknowledgement; return a wrong result under a valid envelope. The relevant test must fail for the intended reason.

Test both directions. A system that rejects every request can pass many denial tests while being unusable. Every critical guard needs an authorized positive path as well as unauthorized/invalid negatives.

For candidate-code execution, a hash-pinned image, successful exit or signed wrapper is not automatically an independent semantic oracle. The current CI210 forged-verdict finding makes this distinction concrete. Scope trusted verification separately from candidate-controlled test reporting.

For model-driven decisions, freeze representative inputs and independently defined invariants or scored expected outputs. Use held-out cases and material/irrelevant input pairs. Record model/config identity and repeated variability where relevant. Deterministic schema checks alone cannot establish semantic correctness; unlimited repeated model evaluations would add cost without a defined decision rule.

### Test disposition rules

| Disposition | Required reason |
|---|---|
| Keep | Protects a current behavior or uniquely relevant incident/recovery boundary. |
| Repair | Current requirement is valid, but fixture, assertion, selection or environment is wrong. |
| Move to cheaper layer | Equivalent fault detection is demonstrated and the higher-level journey still covers composition. |
| Consolidate | Same supported behavior, environment and fault class are redundantly exercised; retain unique assertions. |
| Quarantine temporarily | Diagnosed instability, owner, expiry, visible coverage gap and compensating check. |
| Retire | Requirement removed/superseded, consumers and persisted/recovery paths reconciled, no unique protection, replacement or accepted absence documented. |

A green replacement alone is insufficient to retire the old test. Run historical fault/negative controls against the replacement. Supported old persisted data, rollback releases and disaster recovery may justify tests for interfaces absent from ordinary traffic.

## 7. Proposed backbone E2E portfolio

These are **journey specifications**, not claims that new tests exist or passed. Map them to current owner tests first. Keep shared setup reusable while retaining each journey's distinct acceptance condition.

| ID | Journey and required observable result | Essential falsifiers and proof boundaries |
|---|---|---|
| J01 | **Read-only objective:** actual allowed operator ingress → current owner/route resolution → bounded worker observation → matching original result → evidence-backed operator answer. No mutation. | Wrong actor/target, unavailable tool, stale route, missing receipt, mismatched request. Mission-Control write ingress is not assumed admitted; use a currently accepted ingress. |
| J02 | **Intent and evidence preservation:** accepted constraints and material source reach compiler and both successor paths, and change the correct resulting decision. | Dropped restriction, empty-vs-absent replacement, stale/revoked source, irrelevant input, changed target, source bytes never read. |
| J03 | **Candidate qualification and publication:** real prepare → actual admitted local tests → trusted verdict → exact immutable publication through the ordinary writer. | Broken source, forged PASS, missing dependencies, source changed after test, invalid receipt, direct/ref-rearm bypass; valid candidates must still progress. |
| J04 | **Request/result recovery:** lose acknowledgement after an effect, restart the relevant process, recover the original outcome without repeating the effect. | Duplicate/out-of-order delivery, timeout, wrong digest, crash before/after persistence, ABA/ref continuity, stale lock and exhausted retry budget. |
| J05 | **Watchtower response:** admitted provider event → correct coverage/detection → durable incident → real Controller receiver → observable acknowledgement and authorized bounded response. | Successful-run storm, benign burst, missing events, duplicate deliveries, unavailable database/receiver, lost ack, restart. A locally recorded ack is not receiver proof. |
| J06 | **Source to installed release:** reviewed package includes required files, installs in an appropriate disposable/native profile, runs expected entry point and reports correct identity. | Missing validator/binary, wrong dependencies/config, old process still serving, incomplete rollout, rollback incompatibility. |
| J07 | **Credential lifecycle:** permitted identity gets only intended capability; expiry/revocation blocks further use; recovery preserves custody and incumbent services. | Wrong App/installation/scope, substituted certificate, stale token, forged provider metadata, recovery leakage. Synthetic proof and real-provider proof remain separate. |
| J08 | **Truthful current-state display:** owner evidence reaches Matrix/Mission-Control with correct status, freshness, exclusions and source drill-down. | Expired last-good data, owner disagreement, hidden skips, source-green displayed as installed-green, disconnected feed. |
| J09 | **Lean operating behavior:** ordinary source and mailbox traffic stays inside agreed publication/start/resource budgets without starving valid work. | Loops of valid publications, duplicate pollers, retries across layers, supervisor restart, sensor outage, mailbox updates invalidating the tested base. |
| J10 | **Recovery and removal:** restore critical state or remove a selected obsolete component in a controlled environment; required journeys and original-effect identities still work. | Backup exists but cannot restore, recovery depends on disabled component, old scheduler returns after reboot, rollback resurrects unsafe format or repeated effect. |

Run contract/component tests frequently, native/integration tests when relevant dependencies change, and the small critical journey portfolio at meaningful composition/release boundaries. Match cadence to risk and invalidators; do not impose an arbitrary test-pyramid ratio.

Use production observations sparingly and distinguish passive observation from a probe that writes a mailbox, causes commits or generates provider activity. Start failure injection in Ecosystem Lab or another already admitted disposable environment. A production game day is a separate consequential action.

## 8. Find legacy runtime, unlinked work and hidden bloat

### Runtime discovery

For each admitted host, collect read-only inventory of:

- system and user services, timers, cron entries, startup scripts and restart policies;
- containers, images, processes, listeners, executable paths and package/build identities;
- Windows services, scheduled tasks and startup registrations relevant to the backbone;
- GitHub Actions events, schedules, matrices, reusable workflows, dispatch routes and required checks;
- provider webhooks, App installations, worker subscriptions and external schedules;
- databases, queues, outboxes, locks/leases, evidence directories, backups, logs and retention jobs;
- service-account and capability metadata, without reading credential values.

Then map **trigger → executable/package → configured owner → callers/dependencies → observed effect → recovery path**. Look for duplicate schedulers, disabled components restarted by supervisors, old checkouts still referenced by units, mismatched config, dormant write credentials and unowned temporary workers.

Do not run unfamiliar test suites on production hosts merely to inventory them. Test collection itself can execute imports and fixtures. Inspect discovery configuration first and use admitted isolation for executable collection.

For Windows effects, refresh current Paths policy, ER033/034 and EN545. Prefer the narrow typed action when sufficient, otherwise the admitted local Desktop Commander route through pinned VPS SSH. Tool exposure and actor admission are independent. The fixed probe cannot enumerate arbitrary tasks or run Linux CI. Consult equivalent eligible routes before concluding an observation is blocked.

### Unadopted-work sweep

Search current owner issues, decision records, open and merged PRs, release manifests, experiment/adoption records and the named durable evidence archives. Use broad conversation history only for discovery leads that lack an identified artifact.

For each material idea or fix, record one disposition:

- adopted and proven for named consumers;
- implemented but awaiting qualification;
- qualified source but awaiting publication/package/install;
- installed but awaiting outcome acceptance;
- accepted decision not yet implemented;
- superseded or rejected with rationale;
- deferred deliberately with owner/revisit condition;
- unknown and requiring reconciliation.

Do not automatically install everything previously built. Some work is obsolete, exploratory, conflicting or superseded. Preserve the evidence and decision even when the code should be retired.

### Safe retirement

1. Identify the superseding decision and actual replacement, if any.
2. Check callers, schedules, stored data, rollback and emergency consumers.
3. Establish baseline outcomes, cost and recovery behavior.
4. Prepare a reversible deactivation/removal change and concrete rollback.
5. Observe a window that covers the component's real cadence and rare-use role.
6. Verify positive journeys, absence of unintended restart and no missing signals.
7. Remove obsolete config/code/permissions through the owner; retain history and required evidence.
8. Reconcile catalog, tests, documentation and operator display.

No traffic in seven days is not proof of uselessness for a monthly task or emergency route. Duplicate implementations can be waste; independently useful recovery paths can be justified redundancy.

## 9. Additional gaps the audit should actively look for

These are hypotheses or required checks, not newly proven production defects.

| Gap | How to look for it | Why it matters |
|---|---|---|
| Unknown coverage denominator | Compare registered scope with repository, runtime and provider inventories. | An apparently green dashboard may omit entire surfaces. |
| Evidence older than the actual subject | Match source/config/dependency/authority identities and invalidators. | A valid historical pass can be irrelevant now. |
| Missing consumer propagation | Follow changes through adapters, validators, readers, persisted state and installers. | Matching schemas do not prove every consumer received the change. |
| Self-validating oracle | Introduce controlled wrong behavior and inspect result production. | The implementation can agree with itself and still be wrong. |
| Invalid verdict promotion | Exercise error, timeout, zero-test, skipped and malformed-result cases. | “No failure reported” may be mislabeled PASS. |
| Permanent safe hold | Exercise a valid authorized positive journey and measure completion. | Safety without liveness cannot deliver the backbone outcome. |
| Retry multiplication | Count retries at ingress, Controller, Compute, worker and provider layers. | Individually bounded retries can multiply into storms. |
| Monitor depends on failed path | Disable that path in isolation and check alternate health evidence. | The sensor can fail silently with its subject. |
| Conflicting concurrent work | Compare active source compositions, leases and accepted dependencies. | Separately good patches may overwrite stronger current behavior. |
| Artifact/source loss | Reconstruct a candidate from saved evidence and verify all required objects/assets. | A patch or partial tree may be insufficient to resume or release. |
| Read advertised as harmless but writing | Enumerate mailbox, log, provider and workflow effects of each probe. | Audit traffic itself can consume resources or trigger CI. |
| Excessive context/history | Measure active retrieval size and superseded instruction exposure. | Repeated nested handoffs can reintroduce stale directions and waste reasoning effort. |
| State-store growth | Measure rates and retention for logs, evidence, outboxes, retries and artifacts. | Disk/inode pressure can break recovery before CPU becomes a problem. |
| Restore and clock assumptions | Isolated restore, expiry/clock-skew and persisted-version tests. | A backup or timestamp check can look correct without being operationally sound. |
| Hidden shared-resource coupling | Compare audit/test and control-plane CPU, memory, I/O, locks and permissions. | Local CI may interfere with the always-on backbone it is supposed to protect. |
| Scope and permission drift | Compare actual service identities, App coverage and write routes with accepted scope. | Old privileges and bypass routes can outlive the code that justified them. |

## 10. Execution sequence that avoids audit bloat

| Pass | Work | Concrete output and exit condition |
|---|---|---|
| A0 — Establish scope | Refresh existing owner outcomes, current plans, source identities, active work and authorization boundaries. | Frozen initial inventory and exclusions; every unknown has a specific discovery task. |
| A1 — Compare intended and actual | Reconcile repository/provider metadata and admitted host inventory. | Every discovered active item has an owner/purpose/status or an explicit orphan finding. |
| A2 — Trace outcomes and tests | Map critical journeys to actual tests, selection rules, environments and original results. | Named coverage gaps, suspect assertions, unexecuted tests and protected legacy cases. |
| A3 — Reconcile unadopted work | Follow accepted decisions/repairs through all consumers and deployment stages. | One disposition per selected item; no duplicate remediation plan for an existing owner issue. |
| A4 — Falsify the important claims | In admitted isolation, exercise current code, targeted mutations, contract pairs, cold recovery and native requirements. | Clear source/native/installed distinctions; both safe denial and positive liveness demonstrated where claimed. |
| A5 — Prepare improvements | Rank changes by user impact, recurrence, confidence, reversibility and dependency. | Small reviewable repair/adoption/retirement batches with tests, cost delta and rollback. |
| A6 — Verify accepted changes | Execute only within existing authorization, then observe actual target outcomes and reconcile owners. | Evidence-backed closure for each selected finding; unresolved items remain visible. |
| A7 — Maintain the result | Use existing change/release mechanisms to refresh affected mappings and invalidate obsolete evidence. | Small derived current view, measured operating burden and scheduled reviews only if later selected. |

**Recommended first execution slice:** A0–A3 for CI210/Watchtower, Paths81/EN545 and PROGRAMSTART256, while creating the complete initial backbone denominator. These already have concrete evidence, known owners and cross-system failure modes. Broaden from those edges to the remaining core. This is sequencing, not permission to leave other core components out.

Do not halt all audit discovery because one native profile is unavailable. Continue independent read-only/source work and name the precise missing binding. Conversely, “keep going” does not convert a fixed diagnostic into a generic test runner or authorize new credentials.

Any future production modification, runtime injection, permission change or hosted CI activation must follow its current owner and user authorization. This report itself selects none of those effects. Existing hosted-CI holds must be preserved and freshly observed when relevant; the research did not verify their live enabled/disabled state.

## 11. Measure lean operation by outcomes and cost

Establish a baseline before setting numerical targets. Avoid invented percentages or claiming savings from fewer YAML lines.

| Measure | Useful interpretation |
|---|---|
| Correct useful completions / eligible attempts | Primary reliability measure; also show holds, failures and unknowns separately so the denominator cannot be improved by rejecting valid work. |
| Time to useful result and time to recover | Include queue, lookup, execution, acknowledgement and operator waiting. |
| Human interventions per useful completed task | Distinguish genuine decisions from avoidable command/result relay. |
| Critical outcome coverage | Named outcome and failure-boundary denominator with current proof, not raw line coverage. |
| CI starts, jobs, execution minutes and cancellations | Separate units; provider run count is not billed cost. |
| Duplicate execution and publication amplification | Original source changes versus actual downstream work, grouped by stable identity. |
| Test feedback time, flakes and escaped defects | Count initial outcomes and retries separately; retain full required qualification. |
| Idle resource and storage growth | CPU, RSS, I/O, disk/inodes, retained artifacts and egress where measurable. |
| Adoption lag | Accepted decision/qualified fix to actual consumer/runtime acceptance. |
| Orphans and unexplained divergences | Runtime without owner, decision without disposition, test without requirement, installed artifact without matching provenance. |
| Documentation/context overhead | Active instruction size, conflicting entry points, manual copies and repeated rediscovery. |
| Recovery readiness | Restore success, bounded replay, preserved identity and actual positive liveness after recovery. |

A useful proposed cost ratio is **total execution + inference + provider + operator effort per accepted useful outcome**. Report its ingredients rather than a fabricated combined dollar number. An optimization is accepted only when cost/burden falls and required behavior, trust and recovery do not regress.

No recurring automation was created here. Once an initial baseline exists, reasonable candidates are change-driven invalidation, a lightweight periodic orphan/cost review and bounded recovery exercises at an owner-selected cadence.

## 12. Acceptance and critical review of this proposal

The audit is ready to close for a declared scope only when:

- all in-scope inventory/discovery surfaces have an explicit status, including inaccessible ones;
- current owners, installed/source/config identities and dependency edges are mapped or tracked as exceptions;
- every critical outcome has named positive and negative proof requirements;
- all selected tests have a disposition and honest execution accounting;
- each unadopted improvement is reconciled through an existing owner;
- legacy-removal claims include dependency, recovery, observation-window and rollback evidence;
- changes have demonstrated useful outcomes and measured cost/burden effects;
- operator-facing status preserves uncertainty and source/installed distinctions;
- unresolved risks have owners and explicit dispositions; none are hidden by a global green score;
- future changes have a lightweight invalidation/update mechanism.

This is not a claim of universal correctness. Completeness is scoped, evidence ages, and some risks require future operational observation.

### Author's challenge of the approach

| Tempting shortcut | Why it fails | Correction |
|---|---|---|
| Run all current tests and call it audited. | Test relevance, selection, subject and oracle may be wrong. | Map outcomes and falsifiers before accepting results. |
| Delete old tests and code to become lean. | Compatibility and emergency behavior may still depend on them. | Retire by accepted purpose and dependency evidence. |
| Implement every unfinished idea. | Some ideas are superseded or add more machinery than benefit. | Require a disposition and demonstrated need. |
| Consolidate everything into one service/schema. | Can erase useful ownership and trust boundaries. | Consolidate redundant mechanisms only after measuring their purpose. |
| Add a new global observability/control platform. | Creates another integration and maintenance burden. | Start with existing records and generated views. |
| Treat every missing proof as a new human approval. | Many gaps are source discovery, fixtures, packaging or admitted-route work. | Resolve machine-solvable prerequisites; ask only for a genuinely missing decision. |
| Treat every safe hold as success. | The backbone may become unable to do valid work. | Require positive liveness alongside safety. |
| Preserve history by copying all of it into every active prompt. | Context grows and superseded instructions become hard to distinguish. | Keep one concise current view with immutable evidence links and explicit supersession. |

This is an author review, not a formal Program Start Cycle Challenge, independent reviewer clearance or owner acceptance. If converted into an executable multi-owner plan, challenge the concrete candidate and complete execution prompt under the current canonical PROGRAMSTART protocol before consequential adoption.

### Short continuation brief

> Continue BACKBONE-AUDIT-2026-10-27 as a core-backbone audit. Refresh its cited owner records and any later amendments first. Begin with A0–A3: establish the complete scoped inventory, reconcile intended versus actual state, map critical outcomes to actual tests, and disposition unadopted work. Keep repository and machine inspection read-only; do not create mailbox requests or run executable collections without the appropriate current effect admission. Reuse existing owner plans and evidence. Preserve corrected CI210/PR579/Paths81/PROGRAMSTART256 findings, distinguish source/native/installed/natural proof, and record unknown coverage rather than inferring absence. Produce one linked findings register and prioritized reviewable changes. Do not enable hosted CI, merge, deploy, retire services or change credentials from this brief alone.

## Appendix A. Internal evidence references

These links identify current reference files or owner records; refresh mutable sources before execution.

- **I01 — Morning CI incident audit:** [CI_FAILURE_AUDIT_2026-10-27_PR579.md](https://chatgpt.com/library?file_id=libfile_07debe04a3a88191921e55c1e947448c&account_id=personal). Retrieved modified time 2026-10-27T11:22:04Z. Historical incident baseline.
- **I02 — Current CI210/Watchtower governing reference:** [WATCHTOWER_CI_STORM_OVERNIGHT_HANDOFF_2026-10-24.md](https://chatgpt.com/library?file_id=libfile_e917afaa81f88191babae26f08cff30d&account_id=personal). Retrieved modified time 2026-10-27T18:33:42Z, 98,600 bytes. Revision 18 plus later amendments, including Q06. The filename date does not identify its newest content.
- **I03 — Paths lookup durability reference:** [PATHS56_PR81_EN545_LOOKUP_DURABILITY_2026-10-27.md](https://chatgpt.com/library?file_id=libfile_9920a8e706348191b8fac9c201878d6e&account_id=personal). Retrieved modified time 2026-10-27T14:59:21Z.
- **I04 — Contract propagation reference:** [ECOSYSTEM_CONTRACT_PROPAGATION_CHALLENGED_GAMEPLAN_AND_PROMPT_2026-10-25.md](https://chatgpt.com/library?file_id=libfile_f861b4c75e688191bd0b6f4cb5974654&account_id=personal). Retrieved modified time 2026-10-25T23:04:46Z. Read active checkpoint before historical retained sections.
- **I05 — Backbone semantics reference:** [BACKBONE_P3_CONTRACT_GAMEPLAN_AND_PROMPT_2026-10-25.md](https://chatgpt.com/library?file_id=libfile_87d1d1129d38819199949e525a3d7341&account_id=personal). Retrieved modified time 2026-10-25T22:23:03Z; revision 3 supersedes the broader schema recommendation.
- **I06 — Current EN diagnostic source:** [PR579](https://github.com/GrahamArdent/execution-node-control/pull/579), directly read, draft/open/unmerged at `11b11950e92bfe262b46d861bb7a943ef45a299a`.
- **I07 — Current CI210 owner and recent hardening:** [Compute210](https://github.com/GrahamArdent/programstart-compute-spine/issues/210) and [Q02–Q04 owner checkpoint](https://github.com/GrahamArdent/programstart-compute-spine/issues/210#issuecomment-6449807743). Directly read; later Q06 detail is in I02.
- **I08 — Current lookup source:** [Paths PR81](https://github.com/GrahamArdent/paths/pull/81), directly read, draft/open/unmerged at `83e22aadbb07f07b39badda1a2b7a914c058dc21`.
- **I09 — Semantics owner:** [PROGRAMSTART256](https://github.com/GrahamArdent/PROGRAMSTART/issues/256) and [H2/propagation checkpoint](https://github.com/GrahamArdent/PROGRAMSTART/issues/256#issuecomment-6404646890), directly read.
- **I10 — Windows route ownership:** [EN545](https://github.com/GrahamArdent/execution-node-control/issues/545), [current Paths policy](https://github.com/GrahamArdent/paths/blob/main/policies/chatgpt-windows-default.md) and [effect registry](https://github.com/GrahamArdent/paths/blob/main/registry/effect-reachability.json), directly read.
- **I11 — Sensor ownership:** [Watchtower34](https://github.com/GrahamArdent/repo-watchtower/issues/34), directly read. Its issue body is an earlier checkpoint; interpret with the later I02 reference.

Raw underlying test archives were not re-executed or independently reconstructed in this research. Statements about their results are attributed to the current records above.

## Appendix B. Repository entry-point snapshot

README content is orientation evidence, not a substitute for current owner decisions or live deployment proof. Git blob identifiers below bind the exact README bytes inspected, not the repository HEAD.

| Repository | README Git blob |
|---|---|
| [paths](https://github.com/GrahamArdent/paths/blob/main/README.md) | `4cce5a4551ca438f51afe54b060a5e15a24ff388` |
| [PROGRAMSTART](https://github.com/GrahamArdent/PROGRAMSTART/blob/main/README.md) | `c6c6aa3466d266aa9a2ebf65f01698b0b7896ae2` |
| [programstart-autonomous-controller](https://github.com/GrahamArdent/programstart-autonomous-controller/blob/main/README.md) | `da6f3867f268a6656536cb09fbfe39df2c08d17e` |
| [programstart-compute-spine](https://github.com/GrahamArdent/programstart-compute-spine/blob/main/README.md) | `221aa6a0ace98d259c903cb190fb2fc81169d891` |
| [execution-node-control](https://github.com/GrahamArdent/execution-node-control/blob/main/README.md) | `ed80e3533034a9ff77f1e727a64bf70012b55484` |
| [secrets-control-plane](https://github.com/GrahamArdent/secrets-control-plane/blob/main/README.md) | `b06eb41a564dc46cd9f9fde0f294cb16fca96ecf` |
| [repo-watchtower](https://github.com/GrahamArdent/repo-watchtower/blob/master/README.md) | `fdcd03102215e5b999239a5ed0a154fce5d59741` |
| [ecosystem-matrix](https://github.com/GrahamArdent/ecosystem-matrix/blob/main/README.md) | `f866c58bc2c9b78dadbcab671fc398ab0c7074c6` |
| [evidence-spine](https://github.com/GrahamArdent/evidence-spine/blob/main/README.md) | `3f718b0fae4087b8585dd8f201be8dd788992dff` |
| [mission-control](https://github.com/GrahamArdent/mission-control/blob/main/README.md) | `42aa2c8cc190a6fce7be1699c9832a76668ac724` |
| [ecosystem-lab](https://github.com/GrahamArdent/ecosystem-lab/blob/main/README.md) | `ad8832626e05bed23dc6485543db4f9bc679167b` |
| [decision-lifecycle](https://github.com/GrahamArdent/decision-lifecycle/blob/main/README.md) | `649d465728465b9ac621659865cbe120b66ef738` |

## Appendix C. External sources

All sources were retrieved on October 27, 2026. These are primary framework, specification, research or maintainer sources. Older foundational publications are used for durable engineering principles, not as claims about present ecosystem implementation.

- **R01:** NIST, [The Cybersecurity Framework 2.0](https://nvlpubs.nist.gov/nistpubs/CSWP/NIST.CSWP.29.pdf), February 26, 2024; especially ID.AM and lifecycle/flow inventory.
- **R02:** Google SRE, [Testing for Reliability](https://sre.google/sre-book/testing-reliability/); test layers, operational configuration and production evidence.
- **R03:** Google SRE, [Simplicity](https://sre.google/sre-book/simplicity/); accidental complexity, dead code, APIs and modularity.
- **R04:** DORA, [Test automation](https://dora.dev/capabilities/test-automation/); fast feedback, suite curation and meaningful acceptance coverage.
- **R05:** Google Research, [State of Mutation Testing at Google](https://research.google/pubs/state-of-mutation-testing-at-google/), 2018; efficacy and selective analysis.
- **R06:** Google Testing Blog, [Flaky Tests at Google and How We Mitigate Them](https://testing.googleblog.com/2016/05/flaky-tests-at-google-and-how-we.html), May 27, 2016; signal quality and mitigation tradeoffs. Historical Google statistics are not extrapolated to Graham's ecosystem.
- **R07:** Pact maintainers, [Introduction to contract testing](https://docs.pact.io/); executable consumer/provider examples.
- **R08:** SLSA, [Version 1.2 provenance](https://slsa.dev/spec/v1.2/provenance) and [build provenance](https://slsa.dev/spec/v1.2/build-provenance). The initially retrieved 1.1 page identified itself as retired; this report uses the current 1.2 documentation.
- **R09:** OpenTelemetry, [Context propagation](https://opentelemetry.io/docs/concepts/context-propagation/); causal correlation and trust limitations.
- **R10:** AWS Builders' Library, [Making retries safe with idempotent APIs](https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/); explicit original-request identity and atomic handling.
- **R11:** GitHub Docs, [Control workflow concurrency](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency).
- **R12:** GitHub Docs, [Skipping workflow runs](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/skip-workflow-runs); required-check pending behavior.
- **R13:** Backstage maintainers, [Software Catalog](https://backstage.io/docs/features/software-catalog/); source-owned metadata and discoverable ownership. No deployment is proposed.
- **R14:** Google SRE Workbook, [Implementing SLOs](https://sre.google/workbook/implementing-slos/); outcome-based reliability priorities.
- **R15:** Google SRE, [Monitoring Distributed Systems](https://sre.google/sre-book/monitoring-distributed-systems/); external behavior and actionable signals.
- **R16:** [Principles of Chaos Engineering](https://principlesofchaos.org/), March 2019; measurable hypotheses, controlled faults and bounded impact.

## Appendix D. Request-to-report coverage check

| Requested concern | Where addressed |
|---|---|
| Core backbone, excluding unrelated products | Section 3 inclusion rule and component scope |
| What tests and E2Es exist or should exist | Sections 4, 6 and 7; actual counts remain a declared inventory deliverable |
| Legacy tests that should be removed | Sections 6 and 8 disposition and retirement criteria |
| Useful prior work that remains unimplemented/unlinked | Sections 4, 5 and 8 adoption reconciliation |
| Old runtime components still operating | Section 8 runtime discovery; F11 explicitly preserves the current unknown |
| Stay organized | Sections 5 and 10: one register, four derived views, existing owners |
| Operate leanly without harmful bloat | Sections 1, 8 and 11: purpose, controlled removal and measured cost per outcome |
| Identify additional gaps | Section 9 hypotheses and Section 12 critical review |
| External research | Section 2 and Appendix C, 16 primary-source research groups |
| Durable, reusable audit | This single report, stable reference ID and linked evidence; no competing execution authority |

**Closing disposition:** Recommended approach is ready for review and scoped audit discovery. Full-system assurance, native execution, retirement decisions, production changes and operational acceptance remain to be earned through the existing owners.

